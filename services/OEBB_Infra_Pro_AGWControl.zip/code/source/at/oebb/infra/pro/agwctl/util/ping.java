package at.oebb.infra.pro.agwctl.util;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.InetAddress;
// --- <<IS-END-IMPORTS>> ---

public final class ping

{
	// ---( internal utility methods )---

	final static ping _instance = new ping();

	static ping _newInstance() { return new ping(); }

	static ping _cast(Object o) { return (ping)o; }

	// ---( server methods )---




	public static final void check (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(check)>> ---
		// @sigtype java 3.5
		// [i] field:0:required host
		// [i] field:0:optional timeout
		// --- Inputs ---
		IDataCursor input = pipeline.getCursor();
		String host     = IDataUtil.getString(input, "host");
		String timeoutS = IDataUtil.getString(input, "timeout");
		input.destroy();
		
		// --- Defaults ---
		int timeout = 2_000;
		if (timeoutS != null && !timeoutS.isEmpty()) {
		    try { timeout = Integer.parseInt(timeoutS.trim()); }
		    catch (NumberFormatException ignored) {}
		}
		
		// --- Execute ---
		String reachable    = "false";
		String responseTime = "-1";
		
		if (host != null && !host.isEmpty()) {
		    long start = System.currentTimeMillis();
		    try {
		        boolean reached = InetAddress.getByName(host).isReachable(timeout);
		        long elapsed    = System.currentTimeMillis() - start;
		        reachable    = reached ? "true" : "false";
		        responseTime = reached ? String.valueOf(elapsed) : "-1";
		    } catch (Exception ignored) {}
		}
		
		// --- Outputs ---
		IDataCursor output = pipeline.getCursor();
		IDataUtil.put(output, "host",          host != null ? host : "");
		IDataUtil.put(output, "reachable",     reachable);
		IDataUtil.put(output, "response_time", responseTime);
		output.destroy();
		// --- <<IS-END>> ---

                
	}
}

