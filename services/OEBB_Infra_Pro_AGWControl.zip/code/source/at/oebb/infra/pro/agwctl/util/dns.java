package at.oebb.infra.pro.agwctl.util;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.InetAddress;
import java.net.URI;
// --- <<IS-END-IMPORTS>> ---

public final class dns

{
	// ---( internal utility methods )---

	final static dns _instance = new dns();

	static dns _newInstance() { return new dns(); }

	static dns _cast(Object o) { return (dns)o; }

	// ---( server methods )---




	public static final void resolve (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(resolve)>> ---
		// @sigtype java 3.5
		// [i] field:0:required url
		// --- Inputs ---
		IDataCursor input = pipeline.getCursor();
		String url = IDataUtil.getString(input, "url");
		input.destroy();
		
		// --- Execute ---
		String host       = "";
		String resolvedIp = "";
		
		if (url != null && !url.isEmpty()) {
		    // Extract hostname from URL; fall back to treating the raw
		    // value as a plain hostname if URI parsing fails
		    try {
		        String parsed = new URI(url).getHost();
		        host = (parsed != null && !parsed.isEmpty()) ? parsed : url;
		    } catch (Exception ignored) {
		        host = url;
		    }
		
		    // Resolve hostname to IP address
		    try {
		        resolvedIp = InetAddress.getByName(host).getHostAddress();
		    } catch (Exception ignored) {}
		}
		
		// --- Outputs ---
		IDataCursor output = pipeline.getCursor();
		IDataUtil.put(output, "host",        host);
		IDataUtil.put(output, "resolved_ip", resolvedIp);
		output.destroy();
		// --- <<IS-END>> ---

                
	}
}

