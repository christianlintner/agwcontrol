package at.oebb.infra.pro.agwctl.util;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
// --- <<IS-END-IMPORTS>> ---

public final class http

{
	// ---( internal utility methods )---

	final static http _instance = new http();

	static http _newInstance() { return new http(); }

	static http _cast(Object o) { return (http)o; }

	// ---( server methods )---




	public static final void check (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(check)>> ---
		// @sigtype java 3.5
		// [i] field:0:required url
		// [i] field:0:optional conn_timeout
		// [i] field:0:optional read_timeout
		// [i] field:0:optional insecure
		// --- Inputs ---
		IDataCursor input = pipeline.getCursor();
		String url          = IDataUtil.getString(input, "url");
		String connTimeoutS = IDataUtil.getString(input, "conn_timeout");
		String readTimeoutS = IDataUtil.getString(input, "read_timeout");
		String insecureS    = IDataUtil.getString(input, "insecure");
		input.destroy();
		
		// --- Defaults ---
		int connTimeout = 10_000;
		int readTimeout = 15_000;
		
		if (connTimeoutS != null && !connTimeoutS.isEmpty()) {
		    try { connTimeout = Integer.parseInt(connTimeoutS.trim()); }
		    catch (NumberFormatException ignored) {}
		}
		if (readTimeoutS != null && !readTimeoutS.isEmpty()) {
		    try { readTimeout = Integer.parseInt(readTimeoutS.trim()); }
		    catch (NumberFormatException ignored) {}
		}
		
		boolean insecure = "true".equalsIgnoreCase(insecureS);
		
		// --- Execute ---
		String  httpStatus = "0";
		String  reachable  = "false";
		String  errorMsg   = "";
		
		if (url == null || url.isEmpty()) {
		    errorMsg = "url parameter is required";
		} else {
		    try {
		        int code = doRequest(url, "HEAD", connTimeout, readTimeout, insecure);
		        if (code == 405) {
		            code = doRequest(url, "GET", connTimeout, readTimeout, insecure);
		        }
		        httpStatus = String.valueOf(code);
		        reachable  = code > 0 ? "true" : "false";
		
		    } catch (Exception e) {
		        errorMsg = e.getMessage() != null ? e.getMessage() : e.getClass().getSimpleName();
		    }
		}
		
		// --- Outputs ---
		IDataCursor output = pipeline.getCursor();
		IDataUtil.put(output, "url",         url != null ? url : "");
		IDataUtil.put(output, "http_status", httpStatus);
		IDataUtil.put(output, "reachable",   reachable);
		IDataUtil.put(output, "error_msg",   errorMsg);
		output.destroy();
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	private static int doRequest(String urlStr, String method,
	                             int connTimeout, int readTimeout,
	                             boolean insecure) throws IOException {
	    URL url;
	    try {
	        url = new URI(urlStr).toURL();
	    } catch (URISyntaxException | MalformedURLException | IllegalArgumentException e) {
	        throw new IllegalStateException("Invalid URL: " + urlStr, e);
	    }
	
	    HttpURLConnection conn;
	    if ("https".equalsIgnoreCase(url.getProtocol())) {
	        HttpsURLConnection https = (HttpsURLConnection) url.openConnection();
	        if (insecure) {
	            https.setSSLSocketFactory(trustAllSslContext().getSocketFactory());
	            https.setHostnameVerifier(new HostnameVerifier() {
	                public boolean verify(String hostname, SSLSession session) {
	                    return true;
	                }
	            });
	        }
	        conn = https;
	    } else {
	        conn = (HttpURLConnection) url.openConnection();
	    }
	
	    conn.setConnectTimeout(connTimeout);
	    conn.setReadTimeout(readTimeout);
	    conn.setRequestMethod(method);
	    conn.setInstanceFollowRedirects(true);
	
	    try {
	        return conn.getResponseCode();
	    } finally {
	        conn.disconnect();
	    }
	}
	
	private static SSLContext trustAllSslContext() {
	    TrustManager[] trustAll = new TrustManager[] {
	        new X509TrustManager() {
	            public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
	            public void checkClientTrusted(X509Certificate[] c, String a) {}
	            public void checkServerTrusted(X509Certificate[] c, String a) {}
	        }
	    };
	    try {
	        SSLContext ctx = SSLContext.getInstance("TLS");
	        ctx.init(null, trustAll, null);
	        return ctx;
	    } catch (NoSuchAlgorithmException | KeyManagementException e) {
	        throw new IllegalStateException("Could not create trust-all TLS context", e);
	    }
	}
	// --- <<IS-END-SHARED>> ---
}

