package at.oebb.infra.pro.agwctl.util;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import java.net.URI;
import java.net.URISyntaxException;
// --- <<IS-END-IMPORTS>> ---

public final class url

{
	// ---( internal utility methods )---

	final static url _instance = new url();

	static url _newInstance() { return new url(); }

	static url _cast(Object o) { return (url)o; }

	// ---( server methods )---




	public static final void split (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(split)>> ---
		// @sigtype java 3.5
		// [i] field:0:required url
		// [o] field:0:required host
		// [o] field:0:required port
		// --- Inputs ---
		IDataCursor input = pipeline.getCursor();
		String url = IDataUtil.getString(input, "url");
		input.destroy();
		
		// --- Execute ---
		String host = "";
		String port = "";
		
		if (url != null && !url.trim().isEmpty()) {
			try {
				// Handle URLs passed without a scheme (e.g., "example.com:8080")
				String parsedUrl = url.trim();
				if (!parsedUrl.matches("^[a-zA-Z][a-zA-Z0-9+-.]*://.*")) {
					parsedUrl = "http://" + parsedUrl;
				}
		
				URI uri = new URI(parsedUrl);
				
				String extractedHost = uri.getHost();
				if (extractedHost != null) {
					host = extractedHost;
				}
				
				int extractedPort = uri.getPort();
				if (extractedPort != -1) {
					port = String.valueOf(extractedPort);
				} else if (uri.getScheme() != null) {
					// Fallback to default protocol ports if not explicitly present
					if ("http".equalsIgnoreCase(uri.getScheme())) {
						port = "80";
					} else if ("https".equalsIgnoreCase(uri.getScheme())) {
						port = "443";
					}
				}
			} catch (URISyntaxException e) {
				throw new ServiceException("Invalid URL format: " + e.getMessage());
			}
		}
		
		// --- Outputs ---
		IDataCursor output = pipeline.getCursor();
		IDataUtil.put(output, "host", host);
		IDataUtil.put(output, "port", port);
		output.destroy();
		// --- <<IS-END>> ---

                
	}
}

